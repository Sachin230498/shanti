// Store the wallet amount to your local storage with key "amount"
